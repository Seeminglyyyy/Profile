<?php 
// config.php - database & session bootstrap 

session_start();

//Database Credentials 
$host = '127.0.0.1';
$db = 'misc';
$user = 'fred';
$pw = 'zap';
$dsn = "mysql:host=$host;dbname=$db;charset=utf8";

// PDO options: throw exceptions on errors
$options = [
	PDO:: ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
];

try {
	//Creating the PDO instance
	$pdo = new PDO($dsn, $user, $pw, $options);
}	catch (Exception $e) {
	// If the connection fails, show an error
	die("Database connection failed: " . $e->getMessage());
}
		


//This salt is used for password hashing (NOT to be CHANGED)
$salt = 'XyZzy12*_';

