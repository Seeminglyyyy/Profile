<?php
// logout.php � clear session and return to index
require_once "config.php";
require_once "util.php";

// Clear all session data
session_unset();

// Back to the profile list
header("Location: index.php");
exit();
