<?php
// util.php - helper functions for flash messages and escaping 

function flash_set($msg) {
	$_SESSION['flash'] = $msg;
}

function flash_get() {
	if (isset($_SESSION['flash'])){
		$msg = $_SESSION['flash'];
		unset($_SESSION['flash']);
		return $msg;
	}
	return false;
}

function esc($str){
	return htmlentities($str, ENT_QUOTES, 'UTF-8');
}