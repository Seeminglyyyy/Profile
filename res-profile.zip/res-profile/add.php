<?php
// add.php � add a new profile
require_once "config.php";
require_once "util.php";

// Must be logged in
if ( ! isset($_SESSION['user_id']) ) {
    die("Not logged in");
}

// If user clicked Cancel, go back
if ( isset($_POST['cancel']) ) {
    header("Location: index.php");
    return;
}

// Handle form submission
if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
    // Validate all fields present
    foreach ( ['first_name','last_name','email','headline','summary'] as $field ) {
        if ( ! isset($_POST[$field]) || strlen(trim($_POST[$field])) === 0 ) {
            flash_set("All fields are required");
            header("Location: add.php");
            return;
        }
    }
    // Email must contain @
    if ( strpos($_POST['email'], '@') === false ) {
        flash_set("Email address must contain @");
        header("Location: add.php");
        return;
    }

    // Insert into database
    $stmt = $pdo->prepare('INSERT INTO Profile
      (user_id, first_name, last_name, email, headline, summary)
      VALUES (:uid, :fn, :ln, :em, :he, :su)'
    );
    $stmt->execute([
      ':uid' => $_SESSION['user_id'],
      ':fn'  => $_POST['first_name'],
      ':ln'  => $_POST['last_name'],
      ':em'  => $_POST['email'],
      ':he'  => $_POST['headline'],
      ':su'  => $_POST['summary'],
    ]);
    flash_set("Profile added");
    header("Location: index.php");
    return;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda � Add Profile</title>
</head>
<body>
  <h1>Add A New Profile</h1>
  <?php
    if ( $err = flash_get() ) {
        echo '<p style="color:red">'.esc($err).'</p>';
    }
  ?>
  <form method="post">
    <label>First Name:
      <input type="text" name="first_name" size="60"></label><br/>
    <label>Last Name:
      <input type="text" name="last_name" size="60"></label><br/>
    <label>Email:
      <input type="text" name="email" size="30"></label><br/>
    <label>Headline:<br/>
      <input type="text" name="headline" size="80"></label><br/>
    <label>Summary:<br/>
      <textarea name="summary" rows="8" cols="80"></textarea>
    </label><br/>
    <input type="submit" value="Add" />
    <input type="submit" name="cancel" value="Cancel" />
  </form>
</body>
</html>
