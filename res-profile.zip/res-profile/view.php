<?php
// view.php � show a single profile�s details
require_once "config.php";
require_once "util.php";

// Must have a profile_id in the URL
if ( ! isset($_GET['profile_id']) ) {
    flash_set("Missing profile_id");
    header("Location: index.php");
    return;
}

// Fetch that profile
$stmt = $pdo->prepare('SELECT first_name, last_name, email, headline, summary
                       FROM Profile
                       WHERE profile_id = :pid');
$stmt->execute([ ':pid' => $_GET['profile_id'] ]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ( $row === false ) {
    flash_set("Could not load profile");
    header("Location: index.php");
    return;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda � View Profile</title>
</head>
<body>
  <h1>Profile Information</h1>
  <p><strong>First Name:</strong> <?= esc($row['first_name']) ?></p>
  <p><strong>Last Name:</strong>  <?= esc($row['last_name'])  ?></p>
  <p><strong>Email:</strong>      <?= esc($row['email'])      ?></p>
  <p><strong>Headline:</strong>   <?= esc($row['headline'])   ?></p>
  <p><strong>Summary:</strong><br/>
     <?= nl2br(esc($row['summary'])) ?></p>
  <p><a href="index.php">Back to List</a></p>
</body>
</html>
