<?php
// edit.php � edit an existing profile
require_once "config.php";
require_once "util.php";

// Must be logged in
if ( ! isset($_SESSION['user_id']) ) {
    die("Not logged in");
}

// Must have profile_id
if ( ! isset($_GET['profile_id']) && ! isset($_POST['profile_id']) ) {
    flash_set("Missing profile_id");
    header("Location: index.php");
    return;
}

// If cancel, go home
if ( isset($_POST['cancel']) ) {
    header("Location: index.php");
    return;
}

// Handle POST (update)
if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
    // Validate inputs
    foreach ( ['first_name','last_name','email','headline','summary'] as $field ) {
        if ( ! isset($_POST[$field]) || strlen(trim($_POST[$field])) === 0 ) {
            flash_set("All fields are required");
            header("Location: edit.php?profile_id=".urlencode($_POST['profile_id']));
            return;
        }
    }
    if ( strpos($_POST['email'], '@') === false ) {
        flash_set("Email address must contain @");
        header("Location: edit.php?profile_id=".urlencode($_POST['profile_id']));
        return;
    }

    // Update only if owned by this user
    $stmt = $pdo->prepare('UPDATE Profile SET
        first_name = :fn,
        last_name  = :ln,
        email      = :em,
        headline   = :he,
        summary    = :su
      WHERE profile_id = :pid
        AND user_id    = :uid');
    $stmt->execute([
      ':fn'  => $_POST['first_name'],
      ':ln'  => $_POST['last_name'],
      ':em'  => $_POST['email'],
      ':he'  => $_POST['headline'],
      ':su'  => $_POST['summary'],
      ':pid' => $_POST['profile_id'],
      ':uid' => $_SESSION['user_id'],
    ]);
    flash_set("Profile updated");
    header("Location: index.php");
    return;
}

// If GET, load existing data
$stmt = $pdo->prepare('SELECT first_name, last_name, email, headline, summary, user_id
                       FROM Profile WHERE profile_id = :pid');
$stmt->execute([ ':pid' => $_GET['profile_id'] ]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ( $row === false ) {
    flash_set("Could not load profile");
    header("Location: index.php");
    return;
}
// Check ownership
if ( $row['user_id'] != $_SESSION['user_id'] ) {
    die("Not your profile");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda � Edit Profile</title>
</head>
<body>
  <h1>Edit Profile</h1>
  <?php
    if ( $err = flash_get() ) {
        echo '<p style="color:red">'.esc($err).'</p>';
    }
  ?>
  <form method="post">
    <input type="hidden" name="profile_id" 
           value="<?= esc($_GET['profile_id']) ?>">
    <label>First Name:
      <input type="text" name="first_name" size="60"
             value="<?= esc($row['first_name']) ?>"></label><br/>
    <label>Last Name:
      <input type="text" name="last_name" size="60"
             value="<?= esc($row['last_name']) ?>"></label><br/>
    <label>Email:
      <input type="text" name="email" size="30"
             value="<?= esc($row['email']) ?>"></label><br/>
    <label>Headline:<br/>
      <input type="text" name="headline" size="80"
             value="<?= esc($row['headline']) ?>"></label><br/>
    <label>Summary:<br/>
      <textarea name="summary" rows="8" cols="80"><?= esc($row['summary']) ?></textarea>
    </label><br/>
    <input type="submit" value="Save"/>
    <input type="submit" name="cancel" value="Cancel"/>
  </form>
</body>
</html>
