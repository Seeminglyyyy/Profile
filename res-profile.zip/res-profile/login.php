<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once "config.php";
require_once "util.php";

// If the user clicked �Cancel,� redirect back
if ( isset($_POST['cancel']) ) {
    header("Location: index.php");
    return;
}

// PROCESS POST data
if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
    // Server?side validation
    if ( strlen($_POST['email'] ?? '') < 1 || strlen($_POST['pass'] ?? '') < 1 ) {
        flash_set("Both fields must be filled out");
        header("Location: login.php");
        return;
    }
    if ( strpos($_POST['email'], '@') === false ) {
        flash_set("Email address must contain @");
        header("Location: login.php");
        return;
    }

    // Check credentials
    $check = hash('md5', $salt.$_POST['pass']);
    $stmt = $pdo->prepare(
      'SELECT user_id, name FROM users 
       WHERE email = :em AND password = :pw'
    );
    $stmt->execute([
      ':em' => $_POST['email'],
      ':pw' => $check
    ]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ( $row !== false ) {
        // Success: set session and redirect
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['name']    = $row['name'];
        header("Location: index.php");
        return;
    } else {
        // Failure: flash error
        flash_set("Incorrect email or password");
        header("Location: login.php");
        return;
    }
}

// If we get here, it�s a GET or redirected after a flash
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda � Log In</title>
  <script>
    // Client?side validation
    function doValidate() {
      console.log('Validating...');
      let em = document.getElementById('id_email').value;
      let pw = document.getElementById('id_pass').value;
      if (em === "" || pw === "") {
        alert("Both fields must be filled out");
        return false;
      }
      if (em.indexOf('@') === -1) {
        alert("Email address must contain @");
        return false;
      }
      return true;
    }
  </script>
</head>
<body>
  <h1>Please log in</h1>
  <?php
    if ( $error = flash_get() ) {
        echo '<p style="color:red">'.esc($error).'</p>';
    }
  ?>
  <form method="post">
    <label for="id_email">Email:</label>
    <input type="text" name="email" id="id_email"><br/>
    <label for="id_pass">Password:</label>
    <input type="password" name="pass" id="id_pass"><br/>
    <input type="submit" onclick="return doValidate();" value="Log In">
    <input type="submit" name="cancel" value="Cancel">
  </form>
</body>
</html>
