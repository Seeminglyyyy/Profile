<?php
// delete.php � confirm and delete a profile
require_once "config.php";
require_once "util.php";

// Must be logged in
if ( ! isset($_SESSION['user_id']) ) {
    die("Not logged in");
}

// If cancel, go back
if ( isset($_POST['cancel']) ) {
    header("Location: index.php");
    return;
}

// If delete confirmed, perform it
if ( isset($_POST['delete']) ) {
    $stmt = $pdo->prepare('DELETE FROM Profile
                           WHERE profile_id = :pid
                             AND user_id    = :uid');
    $stmt->execute([
      ':pid' => $_POST['profile_id'],
      ':uid' => $_SESSION['user_id']
    ]);
    flash_set("Profile deleted");
    header("Location: index.php");
    return;
}

// Otherwise (GET), show confirmation
if ( ! isset($_GET['profile_id']) ) {
    flash_set("Missing profile_id");
    header("Location: index.php");
    return;
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda � Delete Profile</title>
</head>
<body>
  <h1>Delete Profile</h1>
  <p>Are you sure you want to delete this profile?</p>
  <form method="post">
    <input type="hidden" name="profile_id"
           value="<?= esc($_GET['profile_id']) ?>">
    <input type="submit" name="delete" value="Yes, Delete"/>
    <input type="submit" name="cancel" value="Cancel"/>
  </form>
</body>
</html>
