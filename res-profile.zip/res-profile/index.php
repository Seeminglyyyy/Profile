<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once "config.php";
require_once "util.php";

$msg = flash_get();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Ananya Hoda (bbd76d78) � Profiles</title>
</head>
<body>
  <h1>Ananya Hoda</h1>

  <?php if ($msg !== false): ?>
    <p style="color:green"><?= esc($msg) ?></p>
  <?php endif; ?>

  <?php if (! isset($_SESSION['user_id'])): ?>
    <p><a href="login.php">Please log in</a> to add, edit, or delete profiles.</p>
  <?php else: ?>
    <p>Welcome, <?= esc($_SESSION['name']) ?>!
       <a href="logout.php">Log Out</a></p>
    <p><a href="add.php">Add New Profile</a></p>
  <?php endif; ?>

  <table border="1" cellpadding="5" cellspacing="0">
    <tr>
      <th>Name</th>
      <th>Headline</th>
      <th>Action</th>
    </tr>
    <?php
    $stmt = $pdo->query(
      "SELECT profile_id, first_name, last_name, headline, user_id
       FROM Profile
       ORDER BY last_name, first_name"
    );
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
    ?>
      <tr>
        <td>
          <a href="view.php?profile_id=<?= esc($row['profile_id']) ?>">
            <?= esc($row['first_name'] . ' ' . $row['last_name']) ?>
          </a>
        </td>
        <td><?= esc($row['headline']) ?></td>
        <td>
          <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
            <a href="edit.php?profile_id=<?= esc($row['profile_id']) ?>">Edit</a> /
            <a href="delete.php?profile_id=<?= esc($row['profile_id']) ?>">Delete</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
